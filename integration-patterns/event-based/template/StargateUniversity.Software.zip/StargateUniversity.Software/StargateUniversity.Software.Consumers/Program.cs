var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddLogging(configure => configure.AddConsole());

var host = builder.Build();
host.Run();