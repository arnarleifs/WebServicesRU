using System.Net.Http.Json;
using Microsoft.Extensions.Configuration;
using StargateUniversity.Software.Contracts.Dtos.UserManagement;

namespace StargateUniversity.Software.Services.UserManagement;

public class Auth0ManagementService(HttpClient httpClient, IConfiguration configuration) : IAuth0ManagementService
{
    public Task<UserCreationReturnDto?> CreateUser(NewUserInputModel inputModel)
    {
        throw new NotImplementedException();
    }

    public Task AddToEmployeeRole(string? userId)
    {
        throw new NotImplementedException();
    }
}