using System.Text.Json.Serialization;

namespace StargateUniversity.Software.Shared.Handlers;

public class AccessTokenResponse
{
    [JsonPropertyName("access_token")] public string? AccessToken { get; set; } = null!;
    [JsonPropertyName("token_type")] public string TokenType { get; set; } = null!;
    [JsonPropertyName("expires_in")] public int ExpiresIn { get; set; }
}

public class ClientCredentialsHandler(string clientId, string clientSecret, string audience, string tokenEndpoint)
    : DelegatingHandler
{
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        // TODO: Assign token to request
        return await base.SendAsync(request, cancellationToken);
    }

    private async Task<string?> GetTokenAsync()
    {
        // TODO: Implement
        return "";
    }
}