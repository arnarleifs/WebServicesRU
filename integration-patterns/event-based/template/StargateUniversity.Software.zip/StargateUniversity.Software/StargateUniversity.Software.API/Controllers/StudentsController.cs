using Microsoft.AspNetCore.Mvc;
using StargateUniversity.Software.API.Models;
using StargateUniversity.Software.Shared.Queues;

namespace StargateUniversity.Software.API.Controllers;

[ApiController]
[Route("[controller]")]
public class StudentsController(ILogger<StudentsController> logger, IMessagingClient messagingClient) : ControllerBase
{
    [HttpPost("register")]
    public async Task<IActionResult> RegisterStudent([FromBody] StudentRegistrationInputModel inputModel)
    {
        // TODO: Publish to message broker

        return Created();
    }
}